//#START API:: Custom Header 
import de.fau.tf.lgdv.CodeBlocks;
import de.fau.tf.lgdv.json.JsonObjectable;
import de.fau.tf.lgdv.json.JsonObject;

class Foo implements JsonObjectable{
        public JsonObject toJsonObject(){
            return new JsonObject().put("test", 42);
        }
}
public class App {
    public static void main(String[] args){
//#START SOLUTION 
        //Hier könnte Ihr Code stehen
//#END STUDENT
        System.out.println("Hello World {:test}"); //this is line 11
        System.out.println("or anyone else {:checked}");
        int[] testArray = {1,2,3,4,5};
        System.out.println(testArray[2]);
        System.out.println(testArray[-1]);
        CodeBlocks.postResult(new Foo()); //this is line 16
//#START STATIC:: MainOverride Stuff 
    } //this is line 17
}

class MainOverride {
    public static void main(String[] args){
        System.out.println("MainOverride was called");
        App.main(args);        
    }
}
