
                export default {
                                                      value: 1,
                                                    create() {
                                                      console.log("LIB: Creating testPre100")
                                                        let myValue = 10;
                                                        return {
                                                          greet: () => console.log("LIB: GREETINGS2 from testPre100", this.value, myValue++)
                                                      }
                                                    },
                                                    other(){
                                                      console.log("LIB: other function in testPre100")
                                                    },
                                                    init() {
                                                          localStorage.setItem('gdi-sticky', 1)
                                                        console.log("LIB: Hello testPre100")
                                                        this.other();
                                                    },
                                                      update(){
                                                          this.value++;
                                                      }
                                                }
            