
                export default {
                                    init: function() {
                                        console.log("LIB: Hello PLAYGROUND")
                                        testPre100.greet()
                                        const planetSize = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--planet-size'));
                                        this.canvasElement.html("CANVAS:" + planetSize)

                                        console.log("TEST init", this.canvasElement, this.outputElement, this.scope, this.runner);
                                        const universe = $('<div class="universe"></div>')
                                    },
                                    update: function(textData, jsonData) {
                                        console.log("TEST update", jsonData, textData, this.canvasElement, this.outputElement);
                                        this.canvasElement.html("HALLO")
                                        //this.outputElement.html("OUTPUT: " + textData);
                                        testPre100.greet()
                                    },
                                    onASTAvailable: function(ast) {
                                        console.log("TEST AST", ast);
                                    }
                                }
            